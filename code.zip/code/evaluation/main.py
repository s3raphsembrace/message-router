"""Evaluation harness -- scores the router against sample_messages.csv.

    python code/evaluation/main.py                    # run the pipeline and score it
    python code/evaluation/main.py --no-guard         # score the router alone
    python code/evaluation/main.py --predictions p.csv  # score a saved run
    python code/evaluation/main.py --leak-check       # prove no labels reach the router

sample_messages.csv is the only labelled data available. It is read HERE, for
scoring, and nowhere else. The label columns are stripped from every row before
it is handed to context assembly or the router, and --leak-check asserts that no
label value appears anywhere in a rendered prompt.
"""

import argparse
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(HERE)
REPO_ROOT = os.path.dirname(CODE)
sys.path.insert(0, HERE)
for _sub in ("context", "router", "guard"):
    sys.path.insert(0, os.path.join(CODE, _sub))

from aggregates import build_reaction_stats                   # noqa: E402
from apply import apply_guard_all                             # noqa: E402
from assemble import build_context                            # noqa: E402
from loaders import DEFAULT_DATASET, DEFAULT_MEDIA_CACHE, Dataset  # noqa: E402
from metrics import (                                         # noqa: E402
    ACTIONS,
    accuracy,
    action_cost,
    calibration,
    confusion,
    evidence_scores,
    joint_accuracy,
    parse_evidence,
    per_class_report,
    severe_errors,
)
from prompt import render                                     # noqa: E402
from route import RouteStats, route_all                       # noqa: E402
from ledger import (                                          # noqa: E402
    append_run,
    compare,
    git_sha,
    history_table,
    load_runs,
    tradeoffs,
)
from rules import REPORTED_POLICY_ANY, REPORTED_POLICY_UNANIMOUS, GuardPolicy  # noqa: E402

DEFAULT_LEDGER = os.path.join(HERE, "runs.csv")

# The five columns that exist only in sample_messages.csv. They must never travel
# into context assembly or a prompt.
LABEL_COLUMNS = ("action", "message_type", "reason", "confidence", "evidence_message_ids")


def strip_labels(row):
    """A sample row with the answers removed -- the shape messages.csv has."""
    return {k: v for k, v in row.items() if k not in LABEL_COLUMNS}


def build_model_callable():
    """The same Layer 3 client the pipeline uses, so eval scores the real system.

    Returns None when no credentials are configured, or when the caller asked for
    an offline run. The response cache means re-scoring an unchanged prompt costs
    nothing.
    """
    sys.path.insert(0, CODE)
    from envload import load_env
    load_env()
    from client import RouterClient
    client = RouterClient()
    return client if client.available else None


def load_predictions(path):
    with open(path, newline="", encoding="utf-8") as f:
        return {r["message_id"]: r for r in csv.DictReader(f)}


def _fmt(value, spec="%.3f"):
    return "n/a" if value is None else (spec % value)


def _keys_anywhere(node, found):
    """Every dict key appearing anywhere in a nested structure."""
    if isinstance(node, dict):
        for key, value in node.items():
            found.add(key)
            _keys_anywhere(value, found)
    elif isinstance(node, (list, tuple)):
        for item in node:
            _keys_anywhere(item, found)
    return found


def leak_check(dataset, samples, reaction_stats):
    """Prove no label reaches the router. Returns a list of problems.

    Structural rather than textual: the assembled context is inspected for any key
    named like an answer column, and the rendered prompt for the gold reason. A
    gold evidence id appearing as a retrieved candidate is NOT leakage -- that is
    retrieval finding the same history a human found -- so ids are not checked.
    """
    problems = []
    for row in samples:
        stripped = strip_labels(row)
        leaked_cols = set(stripped) & set(LABEL_COLUMNS)
        if leaked_cols:
            problems.append("%s: label column(s) survived stripping: %s"
                            % (row["message_id"], ", ".join(sorted(leaked_cols))))

        context = build_context(stripped, dataset, reaction_stats)
        keys = _keys_anywhere(context, set())
        answer_keys = keys & set(LABEL_COLUMNS)
        if answer_keys:
            problems.append("%s: context contains answer-shaped key(s): %s"
                            % (row["message_id"], ", ".join(sorted(answer_keys))))

        _, user = render(context)
        reason = " ".join((row.get("reason") or "").split()).lower()
        if len(reason) > 25 and reason[:40] in user.lower():
            problems.append("%s: gold reason text appears in the prompt" % row["message_id"])
    return problems


def main(argv=None):
    ap = argparse.ArgumentParser(description="Score the router against sample_messages.csv")
    ap.add_argument("--dataset", default=DEFAULT_DATASET)
    ap.add_argument("--media-cache", default=DEFAULT_MEDIA_CACHE)
    ap.add_argument("--predictions", default="", help="score an existing predictions CSV")
    ap.add_argument("--no-guard", action="store_true", help="score the router without Layer 4")
    ap.add_argument("--no-model", action="store_true",
                    help="skip the model entirely (offline: every row takes the safe "
                         "default). Used by the test suite so it costs no quota.")
    ap.add_argument("--reported-policy", default=REPORTED_POLICY_UNANIMOUS,
                    choices=[REPORTED_POLICY_UNANIMOUS, REPORTED_POLICY_ANY])
    ap.add_argument("--leak-check", action="store_true",
                    help="verify no label reaches the router, then exit")
    ap.add_argument("--ledger", default=DEFAULT_LEDGER,
                    help="append-only record of evaluation runs")
    ap.add_argument("--record", default="",
                    help="append this run to the ledger, described by this string "
                         "(e.g. \"prompt: four-stage reasoning order\")")
    ap.add_argument("--notes", default="", help="free-text note stored with a recorded run")
    ap.add_argument("--history", action="store_true",
                    help="print the run history with deltas, then exit")
    args = ap.parse_args(argv)

    if args.history:
        runs = load_runs(args.ledger)
        print(history_table(runs))
        return 0

    dataset = Dataset(args.dataset, args.media_cache)
    samples = dataset.samples
    if not samples:
        print("ERROR: sample_messages.csv is empty or missing", file=sys.stderr)
        return 2
    reaction_stats = build_reaction_stats(dataset)

    if args.leak_check:
        problems = leak_check(dataset, samples, reaction_stats)
        print("leak check over %d labelled rows" % len(samples))
        if problems:
            print("FAILED (%d):" % len(problems))
            for p in problems[:20]:
                print("  - %s" % p)
            return 1
        print("OK: label columns stripped before assembly; no gold value in any prompt")
        return 0

    # ---- predictions -------------------------------------------------
    overridden = set()
    if args.predictions:
        preds = load_predictions(args.predictions)
        source = args.predictions
        missing = [r["message_id"] for r in samples if r["message_id"] not in preds]
        if missing:
            print("ERROR: predictions missing %d sample row(s): %s"
                  % (len(missing), ", ".join(missing[:5])), file=sys.stderr)
            return 2
    else:
        stripped = [strip_labels(r) for r in samples]
        contexts = {r["message_id"]: build_context(r, dataset, reaction_stats)
                    for r in stripped}
        call_model = None if args.no_model else build_model_callable()
        decisions, route_stats = route_all(stripped, contexts, call_model, RouteStats())
        if not args.no_guard:
            decisions, records = apply_guard_all(
                decisions, contexts, GuardPolicy(reported_policy=args.reported_policy))
            overridden = {r.message_id for r in records if r.disagreement}
        preds = {mid: d.to_row() for mid, d in decisions.items()}
        source = "live pipeline (%s, guard %s)" % (
            "model wired" if call_model else "NO MODEL - safe defaults",
            "off" if args.no_guard else "on")

    gold_actions = [r["action"] for r in samples]
    gold_types = [r["message_type"] for r in samples]
    gold_evidence = [r["evidence_message_ids"] for r in samples]
    pred_actions = [preds[r["message_id"]]["action"] for r in samples]
    pred_types = [preds[r["message_id"]]["message_type"] for r in samples]
    pred_evidence = [preds[r["message_id"]]["evidence_message_ids"] for r in samples]
    pred_conf = []
    for r in samples:
        try:
            pred_conf.append(float(preds[r["message_id"]]["confidence"]))
        except (TypeError, ValueError):
            pred_conf.append(0.0)

    print("=" * 76)
    print("EVALUATION - %d labelled rows" % len(samples))
    print("source: %s" % source)
    print("=" * 76)

    # ---- accuracy ----------------------------------------------------
    act_acc = accuracy(gold_actions, pred_actions)
    typ_acc = accuracy(gold_types, pred_types)
    joint = joint_accuracy(gold_actions, pred_actions, gold_types, pred_types)
    print("\n## Accuracy")
    print("  action        %6.1f%%  (%d/%d)" % (
        act_acc * 100, round(act_acc * len(samples)), len(samples)))
    print("  message_type  %6.1f%%  (%d/%d)" % (
        typ_acc * 100, round(typ_acc * len(samples)), len(samples)))
    print("  both correct  %6.1f%%" % (joint * 100))

    # ---- confusion ---------------------------------------------------
    matrix, unknown = confusion(gold_actions, pred_actions)
    print("\n## Action confusion  (rows = gold, columns = predicted)")
    print("            " + "".join("%9s" % a for a in ACTIONS))
    for g in ACTIONS:
        cells = []
        for p in ACTIONS:
            n = matrix[g][p]
            mark = ""
            if (g, p) in (("notify", "mute"), ("mute", "notify")) and n:
                mark = "!"
            cells.append("%8d%s" % (n, mark or " "))
        print("  %-8s %s" % (g, "".join(cells)))
    if unknown:
        print("  (%d row(s) had an out-of-vocabulary action)" % unknown)

    sev = severe_errors(gold_actions, pred_actions, gold_types)
    cost = action_cost(gold_actions, pred_actions, gold_types)
    print("\n## Asymmetric errors  (the two that matter)")
    print("  gold notify -> predicted mute   : %d   %s" % (
        len(sev["suppressed_notify"]),
        "<-- user missed something they needed" if sev["suppressed_notify"] else ""))
    print("     of which urgent/payment/event: %d" % len(sev["suppressed_notify_urgent"]))
    print("  gold mute   -> predicted notify : %d   %s" % (
        len(sev["intruding_mute"]),
        "<-- user interrupted by junk" if sev["intruding_mute"] else ""))
    print("     of which scam/spam           : %d" % len(sev["intruding_mute_risky"]))
    for key, label in (("suppressed_notify", "suppressed"), ("intruding_mute", "intruded")):
        for idx, gtype in sev[key][:5]:
            print("     %-10s %s (gold type %s)" % (label, samples[idx]["message_id"], gtype))
    print("  weighted cost: %.1f total, %.2f per row (worst case %.1f)"
          % (cost["total"], cost["per_row"], cost["worst_case_per_row"]))

    # ---- message_type breakdown --------------------------------------
    print("\n## message_type, per class")
    print("  %-16s %8s %10s %10s %9s" % ("type", "support", "predicted", "precision", "recall"))
    for row in per_class_report(gold_types, pred_types):
        if not row["support"] and not row["predicted"]:
            continue
        print("  %-16s %8d %10d %10s %9s" % (
            row["label"], row["support"], row["predicted"],
            _fmt(row["precision"], "%.2f"), _fmt(row["recall"], "%.2f")))

    # ---- evidence ----------------------------------------------------
    ev = evidence_scores(gold_evidence, pred_evidence)
    print("\n## Evidence")
    print("  exact set match : %6.1f%%" % (ev["exact_match"] * 100))
    print("  precision       : %s   (tp=%d fp=%d)" % (
        _fmt(ev["precision"]), ev["true_positives"], ev["false_positives"]))
    print("  recall          : %s   (fn=%d)" % (_fmt(ev["recall"]), ev["false_negatives"]))
    print("  F1              : %s" % _fmt(ev["f1"]))
    print("  gold 'none'     : %d rows | predicted 'none': %d rows | agreed: %d"
          % (ev["gold_none"], ev["pred_none"], ev["both_none"]))
    if ev["none_agreement"] is not None:
        print("  none agreement  : %6.1f%%" % (ev["none_agreement"] * 100))

    # ---- calibration -------------------------------------------------
    correct = [g == p for g, p in zip(gold_actions, pred_actions)]
    cal = calibration(pred_conf, correct)
    print("\n## Confidence calibration  (action correctness per confidence bin)")
    print("  %-14s %5s %12s %10s %8s" % ("bin", "n", "mean conf", "accuracy", "gap"))
    for row in cal["bins"]:
        if not row["n"]:
            continue
        print("  %.2f - %.2f   %5d %12s %10s %8s" % (
            row["low"], row["high"], row["n"],
            _fmt(row["mean_confidence"], "%.3f"), _fmt(row["accuracy"], "%.3f"),
            _fmt(row["gap"], "%+.3f")))
    print("  expected calibration error (ECE): %.3f" % cal["ece"])
    if cal["overconfident_bins"]:
        print("  %d bin(s) overconfident by more than 0.10" % cal["overconfident_bins"])
    print("  (positive gap = stated confidence exceeds observed accuracy)")

    # Split by who actually decided the row. The guard writes fixed confidences
    # (0.93 scam, 0.90 reported, 0.88 opt-out, 0.85 muted) onto rows that are right
    # by construction, which flatters the aggregate. Only the router-decided figure
    # says anything about whether the MODEL's stated confidence means something.
    router_idx = [i for i, r in enumerate(samples) if r["message_id"] not in overridden]
    guard_idx = [i for i, r in enumerate(samples) if r["message_id"] in overridden]
    if guard_idx:
        router_cal = calibration([pred_conf[i] for i in router_idx],
                                 [correct[i] for i in router_idx])
        guard_cal = calibration([pred_conf[i] for i in guard_idx],
                                [correct[i] for i in guard_idx])
        router_acc = (sum(1 for i in router_idx if correct[i]) / float(len(router_idx))
                      if router_idx else 0.0)
        guard_acc = (sum(1 for i in guard_idx if correct[i]) / float(len(guard_idx))
                     if guard_idx else 0.0)
        print("")
        print("  split by decider:")
        print("    router-decided : n=%-3d action-acc %5.1f%%  ECE %.3f   <- the meaningful one"
              % (len(router_idx), router_acc * 100, router_cal["ece"]))
        print("    guard-overridden: n=%-3d action-acc %5.1f%%  ECE %.3f   (fixed constants)"
              % (len(guard_idx), guard_acc * 100, guard_cal["ece"]))
    else:
        print("  (no rows were overridden, so this ECE is entirely the router's)")

    # ---- ledger ------------------------------------------------------
    if args.record:
        import datetime as _dt
        if args.predictions:
            model_state = "file"
        elif args.no_model:
            model_state = "none"
        else:
            model_state = os.environ.get("ROUTER_MODEL", "gemini-3.5-flash-lite")
        config = "guard=%s;reported=%s;model=%s" % (
            "off" if args.no_guard else "on", args.reported_policy, model_state)
        record = {
            "timestamp": _dt.datetime.now().replace(microsecond=0).isoformat(),
            "git_sha": git_sha(),
            "change": args.record,
            "config": config,
            "action_acc": round(act_acc, 4),
            "type_acc": round(typ_acc, 4),
            "joint_acc": round(joint, 4),
            "evidence_f1": "" if ev["f1"] is None else round(ev["f1"], 4),
            "evidence_precision": "" if ev["precision"] is None else round(ev["precision"], 4),
            "evidence_recall": "" if ev["recall"] is None else round(ev["recall"], 4),
            "evidence_exact": round(ev["exact_match"], 4),
            "ece": round(cal["ece"], 4),
            "cost_per_row": round(cost["per_row"], 4),
            "severe_suppressed": len(sev["suppressed_notify"]),
            "severe_intruded": len(sev["intruding_mute"]),
            "n_rows": len(samples),
            "notes": args.notes,
        }
        previous = load_runs(args.ledger)
        prev_row = previous[-1] if previous else None
        run_number = append_run(args.ledger, record)

        print("\n" + "=" * 76)
        print("RECORDED as run #%d -> %s" % (run_number, args.ledger))
        print("=" * 76)

        current = load_runs(args.ledger)[-1]
        if prev_row is None:
            print("first recorded run -- no baseline to compare against yet")
        else:
            comparison = compare(prev_row, current)
            print("\ndelta vs run #%s (%s):" % (prev_row["run"], prev_row.get("change", "")[:40]))
            for metric, info in comparison.items():
                if info["verdict"] == "new":
                    continue
                mark = {"better": "BETTER", "worse": "WORSE ", "noise": "noise "}[info["verdict"]]
                if metric in ("severe_suppressed", "severe_intruded"):
                    print("  %-18s %s  %+d   (%d -> %d)" % (
                        metric, mark, info["delta"], info["previous"], info["current"]))
                elif metric in ("ece", "cost_per_row"):
                    print("  %-18s %s  %+.3f  (%.3f -> %.3f)" % (
                        metric, mark, info["delta"], info["previous"], info["current"]))
                else:
                    print("  %-18s %s  %+.1fpp (%.1f%% -> %.1f%%)" % (
                        metric, mark, info["delta"] * 100,
                        info["previous"] * 100, info["current"] * 100))
            warnings = tradeoffs(comparison)
            if warnings:
                print("\nTRADE-OFFS:")
                for w in warnings:
                    print("  ! %s" % w)
            else:
                print("\nno trade-offs detected between accuracy, calibration and evidence")

        print("\n" + history_table(load_runs(args.ledger)))

    if not args.predictions and build_model_callable() is None:
        print("\n" + "!" * 72)
        print("! No model client is wired. These numbers score the safe-default")
        print("! fallback plus the deterministic guard, NOT the router. They are a")
        print("! floor and a proof the harness works, not a result.")
        print("!" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
